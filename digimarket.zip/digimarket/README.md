# 🛍️ DIGIMARKET — Marketplace Numérique

Application web pour acheter et vendre des produits numériques (logos, photos, vidéos).

---

## 🚀 Mettre en ligne en 5 minutes (GRATUIT)

### Étape 1 — Créez un compte GitHub
👉 https://github.com/signup

### Étape 2 — Créez un nouveau dépôt
1. Cliquez sur "New repository"
2. Nommez-le `digimarket`
3. Cliquez "Create repository"

### Étape 3 — Importez les fichiers
1. Sur la page de votre dépôt, cliquez "uploading an existing file"
2. Glissez-déposez TOUS les fichiers de ce dossier
3. Cliquez "Commit changes"

### Étape 4 — Déployez sur Vercel
1. Allez sur https://vercel.com/signup
2. Connectez votre compte GitHub
3. Cliquez "Import" sur votre dépôt `digimarket`
4. Cliquez "Deploy"

✅ Votre application est en ligne à : `digimarket.vercel.app`

---

## 📱 Installer sur téléphone

Une fois en ligne, ouvrez l'adresse dans votre navigateur :
- **iPhone** : Safari → Partager → "Sur l'écran d'accueil"
- **Android** : Chrome → Menu ⋮ → "Ajouter à l'écran d'accueil"

---

## 💰 Fonctionnalités

- ✅ Boutique avec filtres par catégorie
- ✅ Page détail produit
- ✅ Panier avec calcul automatique
- ✅ Commission 10% automatique
- ✅ Formulaire pour publier un produit
- ✅ Historique des commandes
- ✅ Navigation mobile (barre du bas)
- ✅ Sauvegarde du panier (localStorage)

---

## 💳 Ajouter les vrais paiements (Stripe)

1. Créez un compte sur https://stripe.com
2. Récupérez votre clé API
3. Contactez un développeur pour l'intégration (ou demandez à Claude !)

---

Créé avec ❤️ par Claude (Anthropic)
