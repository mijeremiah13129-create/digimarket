import { useState, useEffect } from "react";
import "./index.css";

// ── DONNÉES PRODUITS ──────────────────────────────────────────────
const INITIAL_PRODUCTS = [
  { id: 1, title: "Pack Logo Minimaliste", creator: "DesignPro", price: 12, category: "Logo", emoji: "🎨", sales: 142, rating: 4.9, desc: "20 logos vectoriels modernes, formats SVG & PNG" },
  { id: 2, title: "Photos Nature HD", creator: "PixelArt", price: 8, category: "Photo", emoji: "📸", sales: 89, rating: 4.7, desc: "50 photos haute résolution de paysages naturels" },
  { id: 3, title: "Pack Vidéos Intro", creator: "VideoMaster", price: 25, category: "Vidéo", emoji: "🎬", sales: 67, rating: 4.8, desc: "10 intros animées pour YouTube & Réseaux sociaux" },
  { id: 4, title: "Icônes UI Modernes", creator: "IconStudio", price: 15, category: "Logo", emoji: "✨", sales: 210, rating: 5.0, desc: "500 icônes vectorielles pour applications web/mobile" },
  { id: 5, title: "Portraits Abstraits", creator: "ArtByLena", price: 20, category: "Photo", emoji: "🖼️", sales: 34, rating: 4.6, desc: "30 portraits artistiques en haute définition" },
  { id: 6, title: "Templates Réseaux Sociaux", creator: "SocialKit", price: 18, category: "Vidéo", emoji: "📱", sales: 175, rating: 4.9, desc: "Templates animés pour Instagram, TikTok & YouTube" },
];

const COMMISSION = 0.10;
const CATEGORIES = ["Tous", "Logo", "Photo", "Vidéo"];

// ── COMPOSANT PRINCIPAL ───────────────────────────────────────────
export default function App() {
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [cart, setCart] = useState([]);
  const [filter, setFilter] = useState("Tous");
  const [view, setView] = useState("home");
  const [notif, setNotif] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ title: "", price: "", category: "Logo", desc: "" });
  const [orders, setOrders] = useState([]);

  // Sauvegarde panier dans localStorage
  useEffect(() => {
    const saved = localStorage.getItem("digi_cart");
    if (saved) setCart(JSON.parse(saved));
  }, []);
  useEffect(() => {
    localStorage.setItem("digi_cart", JSON.stringify(cart));
  }, [cart]);

  const showNotif = (msg, type = "success") => {
    setNotif({ msg, type });
    setTimeout(() => setNotif(null), 2800);
  };

  const addToCart = (product) => {
    if (cart.find(p => p.id === product.id)) {
      showNotif("Déjà dans le panier !", "warn");
      return;
    }
    setCart([...cart, product]);
    showNotif(`"${product.title}" ajouté ! 🛒`);
  };

  const removeFromCart = (id) => setCart(cart.filter(p => p.id !== id));

  const total = cart.reduce((s, p) => s + Number(p.price), 0);
  const commission = (total * COMMISSION).toFixed(2);

  const checkout = () => {
    setOrders([...orders, { id: Date.now(), items: [...cart], total, date: new Date().toLocaleDateString("fr-FR") }]);
    setCart([]);
    setView("success");
  };

  const publishProduct = () => {
    if (!form.title || !form.price) { showNotif("Remplissez tous les champs !", "warn"); return; }
    const newProduct = {
      id: Date.now(),
      title: form.title,
      creator: "Moi",
      price: Number(form.price),
      category: form.category,
      emoji: form.category === "Logo" ? "🎨" : form.category === "Photo" ? "📸" : "🎬",
      sales: 0,
      rating: 5.0,
      desc: form.desc || "Nouveau produit",
    };
    setProducts([newProduct, ...products]);
    setForm({ title: "", price: "", category: "Logo", desc: "" });
    showNotif("Produit publié avec succès ! 🎉");
    setView("home");
  };

  const filtered = filter === "Tous" ? products : products.filter(p => p.category === filter);

  return (
    <div style={s.app}>
      <div style={s.blob1} /><div style={s.blob2} />

      {/* NOTIFICATION */}
      {notif && (
        <div style={{ ...s.notif, background: notif.type === "warn" ? "#ef4444" : "#f59e0b" }}>
          {notif.msg}
        </div>
      )}

      {/* HEADER */}
      <header style={s.header}>
        <div style={s.logo} onClick={() => { setView("home"); setSelected(null); }}>
          <span style={s.logoMark}>◈</span>
          <span style={s.logoName}>DIGIMARKET</span>
        </div>
        <div style={s.nav}>
          <button style={view === "home" ? s.navA : s.navB} onClick={() => { setView("home"); setSelected(null); }}>Boutique</button>
          <button style={view === "sell" ? s.navA : s.navB} onClick={() => setView("sell")}>Vendre</button>
          <button style={view === "cart" ? s.navA : s.navB} onClick={() => setView("cart")}>
            🛒 {cart.length > 0 && <span style={s.badge}>{cart.length}</span>}
          </button>
          {orders.length > 0 && (
            <button style={view === "orders" ? s.navA : s.navB} onClick={() => setView("orders")}>
              📦
            </button>
          )}
        </div>
      </header>

      {/* ── PAGE ACCUEIL ── */}
      {view === "home" && !selected && (
        <main style={s.main}>
          <div style={s.hero}>
            <p style={s.heroTag}>✦ MARKETPLACE NUMÉRIQUE</p>
            <h1 style={s.heroH1}>Achetez & Vendez<br /><span style={s.heroAccent}>vos créations</span></h1>
            <p style={s.heroSub}>Photos · Logos · Vidéos · Templates</p>
          </div>
          <div style={s.filters}>
            {CATEGORIES.map(c => (
              <button key={c} style={filter === c ? s.fA : s.fB} onClick={() => setFilter(c)}>{c}</button>
            ))}
          </div>
          <div style={s.grid}>
            {filtered.map(p => (
              <div key={p.id} style={s.card} onClick={() => setSelected(p)}>
                <div style={s.cardImg}>{p.emoji}</div>
                <div style={s.cardBody}>
                  <span style={s.cardCat}>{p.category}</span>
                  <h3 style={s.cardTitle}>{p.title}</h3>
                  <p style={s.cardCreator}>par {p.creator}</p>
                  <div style={s.cardMeta}>
                    <span style={s.cardRating}>★ {p.rating}</span>
                    <span style={s.cardSales}>{p.sales} ventes</span>
                  </div>
                  <div style={s.cardFoot}>
                    <span style={s.cardPrice}>{p.price}€</span>
                    <button style={cart.find(x => x.id === p.id) ? s.btnAdded : s.btnBuy}
                      onClick={e => { e.stopPropagation(); addToCart(p); }}>
                      {cart.find(x => x.id === p.id) ? "✓ Ajouté" : "Acheter"}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ── PAGE DÉTAIL PRODUIT ── */}
      {view === "home" && selected && (
        <main style={s.main}>
          <button style={s.back} onClick={() => setSelected(null)}>← Retour</button>
          <div style={s.detail}>
            <div style={s.detailImg}>{selected.emoji}</div>
            <div style={s.detailInfo}>
              <span style={s.cardCat}>{selected.category}</span>
              <h2 style={s.detailTitle}>{selected.title}</h2>
              <p style={s.detailCreator}>par <strong>{selected.creator}</strong></p>
              <p style={s.detailDesc}>{selected.desc}</p>
              <div style={s.detailMeta}>
                <span style={s.cardRating}>★ {selected.rating}</span>
                <span style={s.cardSales}>{selected.sales} ventes</span>
              </div>
              <div style={s.detailPrice}>{selected.price}€</div>
              <button style={cart.find(x => x.id === selected.id) ? s.btnAdded : s.btnBuyLarge}
                onClick={() => { addToCart(selected); }}>
                {cart.find(x => x.id === selected.id) ? "✓ Déjà dans le panier" : "Ajouter au panier"}
              </button>
            </div>
          </div>
        </main>
      )}

      {/* ── PAGE PANIER ── */}
      {view === "cart" && (
        <main style={s.main}>
          <h2 style={s.pageTitle}>Mon Panier</h2>
          {cart.length === 0 ? (
            <div style={s.empty}>
              <p style={s.emptyIcon}>🛒</p>
              <p style={s.emptyTxt}>Votre panier est vide</p>
              <button style={s.btnPrimary} onClick={() => setView("home")}>Parcourir la boutique</button>
            </div>
          ) : (
            <div>
              {cart.map(p => (
                <div key={p.id} style={s.cartItem}>
                  <span style={s.cartEmoji}>{p.emoji}</span>
                  <div style={s.cartInfo}>
                    <p style={s.cartName}>{p.title}</p>
                    <p style={s.cartBy}>par {p.creator}</p>
                  </div>
                  <span style={s.cartPrix}>{p.price}€</span>
                  <button style={s.btnX} onClick={() => removeFromCart(p.id)}>✕</button>
                </div>
              ))}
              <div style={s.summary}>
                <div style={s.sumRow}><span>Sous-total</span><span>{total}€</span></div>
                <div style={{ ...s.sumRow, color: "#f59e0b" }}>
                  <span>Commission (10%)</span><span>-{commission}€</span>
                </div>
                <div style={{ ...s.sumRow, ...s.sumTotal }}>
                  <span>Total</span><span>{total}€</span>
                </div>
                <button style={s.btnCheckout} onClick={checkout}>Payer maintenant →</button>
                <p style={s.sumNote}>💳 Paiement sécurisé via Stripe</p>
              </div>
            </div>
          )}
        </main>
      )}

      {/* ── PAGE VENDRE ── */}
      {view === "sell" && (
        <main style={s.main}>
          <h2 style={s.pageTitle}>Publier un produit</h2>
          <div style={s.howBox}>
            {[["1", "Créez votre fichier numérique (logo, photo, vidéo...)"],
              ["2", "Remplissez le formulaire ci-dessous"],
              ["3", "Publiez et attendez vos acheteurs"],
              ["4", "Gagnez 90% sur chaque vente !"]].map(([n, t]) => (
              <div key={n} style={s.step}><span style={s.stepN}>{n}</span><p style={s.stepT}>{t}</p></div>
            ))}
          </div>
          <div style={s.sellForm}>
            <label style={s.label}>Nom du produit</label>
            <input style={s.input} placeholder="Ex: Pack de 20 logos minimalistes" value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })} />
            <label style={s.label}>Catégorie</label>
            <select style={s.input} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
              <option>Logo</option><option>Photo</option><option>Vidéo</option>
            </select>
            <label style={s.label}>Prix (€)</label>
            <input style={s.input} placeholder="Ex: 15" type="number" min="1" value={form.price}
              onChange={e => setForm({ ...form, price: e.target.value })} />
            <label style={s.label}>Description</label>
            <textarea style={{ ...s.input, height: "90px", resize: "vertical" }}
              placeholder="Décrivez votre produit..." value={form.desc}
              onChange={e => setForm({ ...form, desc: e.target.value })} />
            <button style={s.btnCheckout} onClick={publishProduct}>Publier mon produit →</button>
          </div>
        </main>
      )}

      {/* ── PAGE COMMANDES ── */}
      {view === "orders" && (
        <main style={s.main}>
          <h2 style={s.pageTitle}>Mes Commandes</h2>
          {orders.map(o => (
            <div key={o.id} style={s.orderBox}>
              <div style={s.orderHeader}>
                <span style={s.orderDate}>📦 Commande du {o.date}</span>
                <span style={s.orderTotal}>{o.total}€</span>
              </div>
              {o.items.map(i => (
                <div key={i.id} style={s.orderItem}>
                  <span>{i.emoji} {i.title}</span>
                  <span style={{ color: "#f59e0b" }}>{i.price}€</span>
                </div>
              ))}
            </div>
          ))}
        </main>
      )}

      {/* ── PAGE SUCCÈS ── */}
      {view === "success" && (
        <main style={s.main}>
          <div style={s.success}>
            <div style={s.successIcon}>🎉</div>
            <h2 style={s.successTitle}>Achat réussi !</h2>
            <p style={s.successTxt}>Vos produits numériques sont disponibles dans vos commandes.</p>
            <button style={s.btnPrimary} onClick={() => setView("home")}>Continuer les achats</button>
            <button style={{ ...s.btnPrimary, background: "transparent", border: "1px solid #f59e0b", color: "#f59e0b", marginTop: "12px" }}
              onClick={() => setView("orders")}>Voir mes commandes</button>
          </div>
        </main>
      )}

      {/* BOTTOM NAV MOBILE */}
      <nav style={s.bottomNav}>
        <button style={s.bnBtn} onClick={() => { setView("home"); setSelected(null); }}>
          <span style={s.bnIcon}>🏪</span>
          <span style={s.bnLabel}>Boutique</span>
        </button>
        <button style={s.bnBtn} onClick={() => setView("sell")}>
          <span style={s.bnIcon}>➕</span>
          <span style={s.bnLabel}>Vendre</span>
        </button>
        <button style={s.bnBtn} onClick={() => setView("cart")}>
          <span style={s.bnIcon}>🛒</span>
          <span style={s.bnLabel}>Panier {cart.length > 0 && `(${cart.length})`}</span>
        </button>
        <button style={s.bnBtn} onClick={() => setView("orders")}>
          <span style={s.bnIcon}>📦</span>
          <span style={s.bnLabel}>Commandes</span>
        </button>
      </nav>
    </div>
  );
}

// ── STYLES ────────────────────────────────────────────────────────
const s = {
  app: { minHeight: "100vh", background: "#0a0a0f", color: "#fff", fontFamily: "'DM Sans', sans-serif", position: "relative", paddingBottom: "80px" },
  blob1: { position: "fixed", top: "-80px", right: "-80px", width: "320px", height: "320px", borderRadius: "50%", background: "radial-gradient(circle, rgba(245,158,11,0.13) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 },
  blob2: { position: "fixed", bottom: "80px", left: "-80px", width: "280px", height: "280px", borderRadius: "50%", background: "radial-gradient(circle, rgba(139,92,246,0.09) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 },
  notif: { position: "fixed", top: "72px", left: "50%", transform: "translateX(-50%)", color: "#000", padding: "11px 22px", borderRadius: "30px", fontWeight: "700", zIndex: 999, fontSize: "13px", boxShadow: "0 4px 20px rgba(0,0,0,0.4)", whiteSpace: "nowrap" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.07)", position: "sticky", top: 0, background: "rgba(10,10,15,0.92)", backdropFilter: "blur(12px)", zIndex: 100 },
  logo: { display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" },
  logoMark: { fontSize: "20px", color: "#f59e0b" },
  logoName: { fontSize: "16px", fontWeight: "700", letterSpacing: "3px", fontFamily: "'Playfair Display', serif" },
  nav: { display: "flex", gap: "6px", alignItems: "center" },
  navB: { background: "transparent", border: "1px solid rgba(255,255,255,0.12)", color: "#aaa", padding: "6px 14px", borderRadius: "20px", cursor: "pointer", fontSize: "13px", position: "relative" },
  navA: { background: "rgba(245,158,11,0.15)", border: "1px solid #f59e0b", color: "#f59e0b", padding: "6px 14px", borderRadius: "20px", cursor: "pointer", fontSize: "13px", fontWeight: "600", position: "relative" },
  badge: { position: "absolute", top: "-5px", right: "-5px", background: "#f59e0b", color: "#000", borderRadius: "50%", width: "16px", height: "16px", fontSize: "10px", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "700" },
  main: { maxWidth: "900px", margin: "0 auto", padding: "28px 16px", position: "relative", zIndex: 1 },
  hero: { textAlign: "center", marginBottom: "36px" },
  heroTag: { color: "#f59e0b", fontSize: "11px", letterSpacing: "3px", marginBottom: "12px" },
  heroH1: { fontFamily: "'Playfair Display', serif", fontSize: "clamp(32px, 7vw, 56px)", fontWeight: "900", lineHeight: 1.1, marginBottom: "12px" },
  heroAccent: { color: "#f59e0b" },
  heroSub: { color: "#666", fontSize: "14px", letterSpacing: "2px" },
  filters: { display: "flex", gap: "8px", justifyContent: "center", marginBottom: "28px", flexWrap: "wrap" },
  fB: { background: "transparent", border: "1px solid rgba(255,255,255,0.12)", color: "#aaa", padding: "7px 18px", borderRadius: "20px", cursor: "pointer", fontSize: "13px" },
  fA: { background: "#f59e0b", border: "1px solid #f59e0b", color: "#000", padding: "7px 18px", borderRadius: "20px", cursor: "pointer", fontSize: "13px", fontWeight: "700" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: "18px" },
  card: { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "16px", overflow: "hidden", cursor: "pointer", transition: "border-color 0.2s" },
  cardImg: { background: "rgba(245,158,11,0.07)", height: "110px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "44px" },
  cardBody: { padding: "16px" },
  cardCat: { fontSize: "10px", letterSpacing: "2px", color: "#f59e0b", textTransform: "uppercase" },
  cardTitle: { fontSize: "15px", fontWeight: "700", margin: "6px 0 3px" },
  cardCreator: { fontSize: "12px", color: "#888", marginBottom: "10px" },
  cardMeta: { display: "flex", gap: "14px", marginBottom: "12px" },
  cardRating: { fontSize: "12px", color: "#f59e0b" },
  cardSales: { fontSize: "12px", color: "#555" },
  cardFoot: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  cardPrice: { fontSize: "18px", fontWeight: "700" },
  btnBuy: { background: "#f59e0b", color: "#000", border: "none", padding: "7px 14px", borderRadius: "18px", cursor: "pointer", fontWeight: "700", fontSize: "12px" },
  btnAdded: { background: "rgba(245,158,11,0.15)", color: "#f59e0b", border: "1px solid #f59e0b", padding: "7px 14px", borderRadius: "18px", cursor: "default", fontSize: "12px" },
  back: { background: "transparent", border: "none", color: "#f59e0b", fontSize: "15px", cursor: "pointer", marginBottom: "20px", padding: 0 },
  detail: { display: "flex", gap: "28px", flexWrap: "wrap" },
  detailImg: { background: "rgba(245,158,11,0.07)", borderRadius: "20px", width: "100%", maxWidth: "280px", height: "200px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "72px" },
  detailInfo: { flex: 1, minWidth: "220px" },
  detailTitle: { fontFamily: "'Playfair Display', serif", fontSize: "26px", fontWeight: "900", margin: "10px 0 6px" },
  detailCreator: { color: "#888", fontSize: "14px", marginBottom: "12px" },
  detailDesc: { color: "#bbb", fontSize: "14px", lineHeight: 1.6, marginBottom: "16px" },
  detailMeta: { display: "flex", gap: "16px", marginBottom: "16px" },
  detailPrice: { fontSize: "32px", fontWeight: "700", color: "#f59e0b", marginBottom: "20px" },
  btnBuyLarge: { background: "#f59e0b", color: "#000", border: "none", padding: "14px 28px", borderRadius: "12px", cursor: "pointer", fontWeight: "700", fontSize: "15px", width: "100%" },
  pageTitle: { fontFamily: "'Playfair Display', serif", fontSize: "28px", fontWeight: "900", marginBottom: "24px", borderBottom: "1px solid rgba(255,255,255,0.07)", paddingBottom: "14px" },
  cartItem: { display: "flex", alignItems: "center", gap: "14px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "12px", padding: "14px", marginBottom: "12px" },
  cartEmoji: { fontSize: "28px" },
  cartInfo: { flex: 1 },
  cartName: { fontWeight: "600", marginBottom: "3px", fontSize: "14px" },
  cartBy: { color: "#888", fontSize: "12px" },
  cartPrix: { fontWeight: "700", color: "#f59e0b", fontSize: "16px" },
  btnX: { background: "transparent", border: "1px solid rgba(255,255,255,0.12)", color: "#888", width: "28px", height: "28px", borderRadius: "50%", cursor: "pointer", fontSize: "11px" },
  summary: { background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: "16px", padding: "22px", marginTop: "8px" },
  sumRow: { display: "flex", justifyContent: "space-between", marginBottom: "10px", fontSize: "14px", color: "#bbb" },
  sumTotal: { borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: "12px", marginTop: "6px", color: "#fff", fontWeight: "700", fontSize: "18px" },
  btnCheckout: { width: "100%", background: "#f59e0b", color: "#000", border: "none", padding: "14px", borderRadius: "12px", cursor: "pointer", fontWeight: "700", fontSize: "15px", marginTop: "16px" },
  sumNote: { textAlign: "center", color: "#555", fontSize: "12px", marginTop: "10px" },
  howBox: { background: "rgba(255,255,255,0.03)", borderRadius: "16px", padding: "22px", marginBottom: "24px" },
  step: { display: "flex", gap: "14px", marginBottom: "16px", alignItems: "flex-start" },
  stepN: { background: "#f59e0b", color: "#000", width: "26px", height: "26px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "700", fontSize: "12px", flexShrink: 0 },
  stepT: { color: "#bbb", fontSize: "14px", lineHeight: 1.5, paddingTop: "3px" },
  sellForm: { display: "flex", flexDirection: "column", gap: "12px" },
  label: { color: "#888", fontSize: "12px", letterSpacing: "1px", textTransform: "uppercase" },
  input: { background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "10px", padding: "12px 14px", color: "#fff", fontSize: "14px", outline: "none" },
  empty: { textAlign: "center", padding: "60px 0" },
  emptyIcon: { fontSize: "60px", marginBottom: "14px" },
  emptyTxt: { color: "#888", fontSize: "16px", marginBottom: "22px" },
  btnPrimary: { display: "block", background: "#f59e0b", color: "#000", border: "none", padding: "12px 26px", borderRadius: "24px", cursor: "pointer", fontWeight: "700", fontSize: "14px", margin: "0 auto" },
  orderBox: { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "14px", padding: "18px", marginBottom: "16px" },
  orderHeader: { display: "flex", justifyContent: "space-between", marginBottom: "14px", alignItems: "center" },
  orderDate: { color: "#888", fontSize: "13px" },
  orderTotal: { color: "#f59e0b", fontWeight: "700" },
  orderItem: { display: "flex", justifyContent: "space-between", fontSize: "14px", padding: "6px 0", borderTop: "1px solid rgba(255,255,255,0.05)" },
  success: { textAlign: "center", padding: "60px 0", display: "flex", flexDirection: "column", alignItems: "center", gap: "12px" },
  successIcon: { fontSize: "72px" },
  successTitle: { fontFamily: "'Playfair Display', serif", fontSize: "32px", fontWeight: "900", color: "#f59e0b" },
  successTxt: { color: "#888", fontSize: "15px", marginBottom: "8px" },
  bottomNav: { position: "fixed", bottom: 0, left: 0, right: 0, background: "rgba(10,10,15,0.96)", borderTop: "1px solid rgba(255,255,255,0.07)", display: "flex", justifyContent: "space-around", padding: "10px 0 14px", zIndex: 100, backdropFilter: "blur(12px)" },
  bnBtn: { background: "transparent", border: "none", color: "#aaa", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: "3px", flex: 1 },
  bnIcon: { fontSize: "20px" },
  bnLabel: { fontSize: "10px", letterSpacing: "0.5px" },
};
